import java.util.ArrayList;
import java.util.Scanner;

public class midtermALIST {

    static ArrayList<String> email = new ArrayList<>();
    static ArrayList<Integer> age = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args){
        int menu = 0;
        List:
        while(true){
            System.out.println("=====Application Form===== \n1. Input your email \n2. Print out your info \n3. Edit your details\n4. Remove your details\n5. Exit form");
            menu = sc.nextInt();
            switch(menu){
                case 1:
                    inputEmail();
                    break;
                case 2:
                    showall();
                    break;
                case 3:
                    editInfo();
                    break;
                case 4:
                    removeAll();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Error");
                    break;
            }
        }
    }
    static void showall(){
        System.out.println("\nInformation entered on the list: ");
        for(int i = 0; i < email.size(); i++){
            System.out.println(email.get(i)+" and his/her age is: "+ age.get(i));
        }
    }
    static void inputEmail(){
        System.out.println("Please input your email: ");
        email.add(sc.next());
        System.out.println("Please input your age: ");
        age.add(sc.nextInt());
        System.out.println("Information has been added to the index.");
    }
    static void editInfo(){
        System.out.println("Enter index to update info: ");
        int index = sc.nextInt();
        System.out.println("Enter updated email: ");
        String updated = sc.next();
        System.out.println("Enter new age: ");
        int new_age = sc.nextInt();
        email.set(index, updated);
        age.set(index,new_age);
        System.out.println("Information has been updated");
    }
    static void removeAll(){
      String del;
        System.out.println("Enter the email you want to remove: ");
        del = sc.next();
        if(email.contains(del)){
            email.remove(del);
            System.out.println(del + " has been removed");
        }
        else {
            System.out.println("No "+ del + " in the list");
        }
    }
}
